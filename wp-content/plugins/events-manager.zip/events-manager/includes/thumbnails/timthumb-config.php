<?php
define ('ALLOW_EXTERNAL', TRUE);
define ('FILE_CACHE_DIRECTORY', '../../../../uploads/em-cache/');