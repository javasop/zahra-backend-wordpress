<?php



class Zahra_API extends WP_JSON_Posts {

 
    public function register_routes( $routes ) {
    
		$hospital_routes = array(
			'/hospitals'             => array(
				array( array( $this, 'get_posts'), WP_JSON_Server::READABLE )
			)
		);
		return array_merge( $routes, $hospital_routes );
		
    }


	public function get_posts( $filter = array(), $context = 'view', $type = 'hospital', $page = 1 ) {

		if ( $type !== 'hospital' ) {
			return new WP_Error( 'json_post_invalid_type', __( 'Invalid post type' ), array( 'status' => 400 ) );
		}

		if ( empty( $filter['post_status'])) {
			$filter['post_status'] = array( 'publish', 'inherit' );

		}

		$posts = parent::get_posts( $filter, $context, 'hospital', $page );

		return $posts;
	}

	/**
	 * Add the featured image data to the post data
	 *
	 * @param array $data Post data
	 * @param array $post Raw post data from the database
	 * @param string $context Display context
	 * @return array Filtered post data
	 */
	public function add_hospital_data( $data, $post, $context ) {

		$data['custom'] = "I am custom data";

		return $data;
	}

}

?>