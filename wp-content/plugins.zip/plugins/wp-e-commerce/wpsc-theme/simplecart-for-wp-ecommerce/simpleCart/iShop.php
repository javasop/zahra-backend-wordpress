<?php
if(get_option('wpsc_selected_theme') == 'simpleCart') {
	function wpsc_theme_html($product) {
		$siteurl = get_option('siteurl');
		$wpsc_theme['html'] ="<input type='image' src='".WPSC_URL."/themes/simpleCart/images/buy_button.gif' id='product_".$product['id']."_submit_button' class='wpsc_buy_button' name='Buy' value='".TXT_WPSC_ADDTOCART."'  />";
		return $wpsc_theme;
	}
}
?>