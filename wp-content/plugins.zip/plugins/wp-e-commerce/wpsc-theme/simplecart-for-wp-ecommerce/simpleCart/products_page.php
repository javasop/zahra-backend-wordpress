<?php
global $wpsc_query, $wpdb;
?>

<div id='products_page_container' class="wrap wpsc_container">

<?php if(wpsc_has_breadcrumbs()) : ?>
		<div class='breadcrumb'>
			<a href='<?php echo get_option('siteurl'); ?>'><?php echo get_option('blogname'); ?></a> &raquo;
			<?php while (wpsc_have_breadcrumbs()) : wpsc_the_breadcrumb(); ?>
				<?php if(wpsc_breadcrumb_url()) :?> 	   
					<a href='<?php echo wpsc_breadcrumb_url(); ?>'><?php echo wpsc_breadcrumb_name(); ?></a> &raquo;
				<?php else: ?> 
					<?php echo wpsc_breadcrumb_name(); ?>
				<?php endif; ?> 
			<?php endwhile; ?>
		</div>
	<?php endif; ?>
	
	<?php do_action('wpsc_top_of_products_page'); // Plugin hook for adding things to the top of the products page, like the live search ?>
	
	<?php if(wpsc_is_in_category()) : ?>
		<div class='wpsc_category_details'>
			<?php if(get_option('show_category_thumbnails') && wpsc_category_image()) : ?>
				<img src='<?php echo wpsc_category_image(); ?>' alt='<?php echo wpsc_category_name(); ?>' title='<?php echo wpsc_category_name(); ?>' />
			<?php endif; ?>
			
			<?php if(get_option('wpsc_category_description') &&  wpsc_category_description()) : ?>
				<?php echo wpsc_category_description(); ?>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	
	<?php if(wpsc_has_pages() && ((get_option('wpsc_page_number_position') == 1 ) || (get_option('wpsc_page_number_position') == 3)))  : ?>
		<div class='wpsc_page_numbers'>
		  Pages: 
			<?php while (wpsc_have_pages()) : wpsc_the_page(); ?>
				<?php if(wpsc_page_is_selected()) :?> 	   
					<a href='<?php echo wpsc_page_url(); ?>' class='selected'><?php echo wpsc_page_number(); ?></a>
				<?php else: ?> 
					<a href='<?php echo wpsc_page_url(); ?>'><?php echo wpsc_page_number(); ?></a>
				<?php endif; ?> 
			<?php endwhile; ?>
		</div>
	<?php endif; ?>
  <ul>
	<?php /** start the product loop here */?>
	<?php while (wpsc_have_products()) :  wpsc_the_product(); ?>
		<li class="productdisplay default_product_display product_view_<?php echo wpsc_the_product_id(); ?> <?php echo wpsc_category_class(); ?>">      
			
				<?php if(get_option('show_thumbnails')) :?>
						<?php if(wpsc_the_product_thumbnail()) :?>
								<img class="product_image" id="product_image_<?php echo wpsc_the_product_id(); ?>" alt="<?php echo wpsc_the_product_title(); ?>" title="<?php echo wpsc_the_product_title(); ?>" src="<?php echo wpsc_the_product_thumbnail(); ?>"/>
						<?php else: ?>
							<div class="item_no_image">
								<a href="<?php echo wpsc_the_product_permalink(); ?>">
								<span>No Image Available</span>
								</a>
							</div>
						<?php endif; ?>
				<?php endif; ?>
				
          <?php echo wpsc_the_product_price(); ?>
					<h3><?php echo wpsc_the_product_title(); ?></h3>
					<?php
						do_action('wpsc_product_addons', wpsc_the_product_id());
						
						if((wpsc_product_has_file() == true)  && (function_exists('listen_button'))){
							$file_data = $wpdb->get_row("SELECT * FROM `".WPSC_TABLE_PRODUCT_FILES."` WHERE `id`='".$wpsc_query->product['file']."' LIMIT 1",ARRAY_A);
							if($file_data != null) {
								echo listen_button($file_data['idhash'], $file_data['id']);
							}
						}
				?>

					<form class='product_form'  enctype="multipart/form-data" action="<?php echo wpsc_this_page_url(); ?>" method="post" name="product_<?php echo wpsc_the_product_id(); ?>" id="product_<?php echo wpsc_the_product_id(); ?>">
						<?php do_action('wpsc_product_addon_after_descr', wpsc_the_product_id()); ?>
												
						<input type="hidden" value="add_to_cart" name="wpsc_ajax_action"/>
						<input type="hidden" value="<?php echo wpsc_the_product_id(); ?>" name="product_id"/>
				
						<!-- END OF QUANTITY OPTION -->
						<?php if(get_option('addtocart_or_buynow') !='1') : ?>
							<?php if(wpsc_product_has_stock()) : ?>
								<div class='wpsc_buy_button_container'>
									<input type='submit' id='product_<?php echo wpsc_the_product_id(); ?>_submit_button' class='wpsc_buy_button' name='Buy'  value="<?php echo TXT_WPSC_ADDTOCART; ?>" />
									<div class='wpsc_loading_animation'>
										<img title="Loading" alt="Loading" src="<?php echo WPSC_URL; ?>/images/indicator.gif" class="loadingimage"/>
										<?php echo TXT_WPSC_UDPATING_CART; ?>
									</div>
								</div>
							<?php else : ?>
								<p class='soldout'><?php echo TXT_WPSC_PRODUCTSOLDOUT; ?></p>
							<?php endif ; ?>
						<?php endif ; ?>
					</form>
					
					<?php if(get_option('addtocart_or_buynow')=='1') : ?>
						<?php echo wpsc_buy_now_button(wpsc_the_product_id()); ?>
					<?php endif ; ?>
					
					<?php echo wpsc_product_rater(); ?>
					
	</li>

	<?php endwhile; ?>
	<?php /** end the product loop here */?>
	</ul>
	<div class="clearboth"></div>
	<?php if(wpsc_product_count() < 1):?>
		<p><?php  echo TXT_WPSC_NOITEMSINTHISGROUP; ?></p>
	<?php endif ; ?>

<?php

if(function_exists('fancy_notifications')) {
  echo fancy_notifications();
}
?>

	<?php if(wpsc_has_pages() &&  ((get_option('wpsc_page_number_position') == 2) || (get_option('wpsc_page_number_position') == 3))) : ?>
		<div class='wpsc_page_numbers'>
		  Pages: 
			<?php while ($wpsc_query->have_pages()) : $wpsc_query->the_page(); ?>
				<?php if(wpsc_page_is_selected()) :?> 	   
					<a href='<?php echo wpsc_page_url(); ?>' class='selected'><?php echo wpsc_page_number(); ?></a>
				<?php else: ?> 
					<a href='<?php echo wpsc_page_url(); ?>'><?php echo wpsc_page_number(); ?></a>
				<?php endif; ?> 
			<?php endwhile; ?>
		</div>
	<?php endif; ?>
</div>