<?php
/**
 * WP eCommerce edit and view sales page functions
 *
 * These are the main WPSC sales page functions
 *
 * @package wp-e-commerce
 * @since 3.7
 */


//don't need this
global $purchlogs;
if(!isset($purchlogs)){
   $purchlogs = new wpsc_purchaselogs();
}

function wpsc_display_sales_logs() {
	$subpage = empty( $_GET['subpage'] ) ? '' : $_GET['subpage'];

	switch( $subpage ) {
		case 'upgrade-purchase-logs':
			wpsc_upgrade_purchase_logs();
		break;

		case 'update-purchase-logs-3.8':
			wpsc_update_purchase_logs_3dot8();
		break;

		default:
			wpsc_display_sales_log_index();
		break;
	}
}

function wpsc_update_purchase_logs_3dot8() {
	if ( _wpsc_purchlogs_need_update() )
		wpsc_update_purchase_logs();

	?>
		<div class="wrap">
			<h2>////<?php //echo esc_html( __('Sales', 'wpsc') ); ?> </h2>
			<p>////<?php //printf( __( 'Your purchase logs have been updated! <a href="%s">Click here</a> to return.'), remove_query_arg( 'subpage' ) ); ?></p>
		</div> 
	//<?php
}

function _wpsc_purchlogs_need_update() {
	global $wpdb;

	if ( get_option( '_wpsc_purchlogs_3.8_updated' ) )
		return false;

	$c = $wpdb->get_var( "SELECT COUNT(*) FROM " . WPSC_TABLE_PURCHASE_LOGS . " WHERE plugin_version IN ('3.6', '3.7')" );
	if ( $c > 0 )
		return true;

	update_option( '_wpsc_purchlogs_3.8_updated', true );
	return false;
}

 function wpsc_display_sales_log_index() {

    global $purchlogitem;

   ?>
   <div class="wrap">
      <h2><?php echo esc_html( __('Sales', 'wpsc') ); ?> </h2>
      <?php //START OF PURCHASE LOG DEFAULT VIEW ?>
      <?php
       if(isset($_GET['view_purchlogs_by']) || isset($_GET['view_purchlogs_by_status']))
         wpsc_change_purchlog_view($_GET['view_purchlogs_by'], $_GET['view_purchlogs_by_status']);

         if(isset($_POST['purchlogs_searchbox']))
            wpsc_search_purchlog_view($_POST['purchlogs_searchbox']);

         
         
         if(!isset($_REQUEST['purchaselog_id'])){
            $columns = array(
               'prod_id' => 'Product_ID',
               'name' => 'Product Name',
               'quantity' => 'Quantity Sold',
               'Clicks' => 'Number of Clicks'
            );
            register_column_headers('display-sales-list', $columns);
            
            
                        $columns = array(
                'order_id' => 'Order_ID',
                 'products' => 'Products Ordered',
                'paymentm' => 'Payment Method',  
                'total' => 'Total Price',
                'status' => 'Status',             
                'Date' => 'Date',
                'buyer' => "Buyer's Name",
                'buyer_p' => "Phone",
                'buyer_m' => "Mobile",
                'buyer_ad' => "Address",
                'Discount' => 'Discount',
                'Coupon' => 'Coupon Code',
                'trans' => 'Transaction ID',
                'status change' => 'Change Status'            
                            
            );
            register_column_headers('display-order-list', $columns);
            
            
?>
      
      <!-- this is the dashboard widget on top -->
      <div id='dashboard-widgets' style='min-width: 825px;'>
         <?php /* end of sidebar start of main column */ ?>
         <div id='post-body' class='has-sidebar metabox-holder' style='width:95%;'>
            <div id='dashboard-widgets-main-content-wpsc' class='has-sidebar-content'>

            <?php
				wp_nonce_field( 'closedpostboxes', 'closedpostboxesnonce', false );
				do_meta_boxes('dashboard_page_wpsc-sales-logs', 'top', true);
			?>
               </div><br />
               
                  <?php wpsc_purchaselogs_displaylist(); ?>

         </div>
         <script type="text/javascript">
         	jQuery(document).ready(function(){postboxes.add_postbox_toggles(pagenow);});
         </script>
      </div>
      <?php } ?>
       
   </div>
   <?php

 }

 function wpsc_purchaselogs_displaylist(){
   global $purchlogs;
  ?>
   <form method='post' action=''>
       
       <!-- orders display  -->
              <p style="font-size: 18px;">Orders</p>
       </br>
      <input type='hidden' name='wpsc_admin_action' value='order_search' />
      <input type='text' value='<?php if(isset($_POST['order_searchbox'])) echo esc_attr( $_POST['order_searchbox'] ); ?>' name='order_searchbox' id='order_searchbox' />
      <input type="submit" value="Search By Buyer's Name"  class="button-secondary action" />
      </br>
      </br>
      <input type='hidden' name='wpsc_admin_action' value='order_date_search' />
      <input type='text' value='<?php if(isset($_POST['order_date_searchbox'])) echo esc_attr( $_POST['order_searchbox'] ); ?>' name='order_searchbox' id='order_searchbox' />
      <input type="submit" value="Search By Date"  class="button-secondary action" />
      
      </br>
      </br>
      <div class='wpsc_purchaselogs_options'>
              <!-- here I will add the filters to the products (most sold . least sold . most clicked . two categories -->  
              <?php /* View functions for purchlogs */ ?> 
              <label for='view_order_by'>Status:</label>
              <!-- the first view by --> 
            <select id='view_order_by_status' name='view_order_by_status'>
                  <option value='msold' ></option>
                  <option value='all'>All</option>
                  <option value='all'>Complete</option>
                  <option value='cmonth'>Incomplete</option>
              </select>
              
              <!-- the second view by --> 
              <label for='view_order_by_status'>Time :</label>
              <select id='view_order_by' name='view_order_by_time'>
                      <option value='msold' ></option>
                      <option value='msold' >Today</option>
                      <option value='lsold'>Most Recent</option>
                  </select>
                            <!-- the second view by --> 
              <label for='view_order_by_status'>Payment Method:</label>
              <select id='view_order_by_payment' name='view_order_by_payment'>
                      <option value='msold' ></option>
                      <option value='msold' >All</option>
                      <option value='msold' >Credit</option>
                      <option value='lsold'>Cash</option>
                      <option value='lsold'>Shipment</option>
                  </select>  
              <input type='hidden' value='purchlog_filter_by' name='wpsc_admin_action' />
              <input type="submit" value="Quick Search" name="doaction2" id="doaction2" class="button-secondary action" />    
          </div>
      </br>
      </br>
     
                    <table class="widefat" style="border-spacing:10px">
         <thead>
            <tr>
         <?php print_column_headers('display-order-list'); ?>
            </tr>
         </thead>
         <tfoot>
            <tr>
         <?php print_column_headers('display-order-list', false); ?>
            </tr>
         </tfoot>
         <tbody>
             <!-- I can add the code here to retrieve things -->
         <?php 
         //i will add another method to retrieve orders and get to order details 
         //get_order_content(); 
         ?>
         </tbody>
      </table> 
       
       </br>
    
       
       
       <p style="font-size: 18px;">Products Statistics</p>
       </br>
       </br>
       
       
       <input type='hidden' name='wpsc_admin_action' value='purchlogs_search' />
      <input type='text'  name='purchlogs_searchbox' id='purchlogs_searchbox' />
      <input type="submit" value="Search Products"  class="button-secondary action" />
      </br>
      </br>
       
       
     <div class='wpsc_purchaselogs_options'>
         <!-- here I will add the filters to the products (most sold . least sold . most clicked . two categories -->  
      <?php /* View functions for purchlogs */?> 
      <label for='view_purchlogs_by'><?php _e('View:'); ?></label>
      <!-- the first view by --> 
      <select id='view_purchlogs_by' name='view_purchlogs_by'>
           <option value='msold' ></option>
          <option value='msold' >Most Sold</option>
          <option value='lsold'>Least Sold</option>
          <option value='clicks'>Most Clicked</option>
      </select>     
      <!-- the second view by --> 
      <label for='view_purchlogs_by_status'>Time:</label>
      <select id='view_purchlogs_by_status' name='view_purchlogs_by_status'>
         <option value='msold' ></option>
         <option value='all'>All time</option>
         <option value='cmonth'>This Month</option>
      </select>
      <input type='hidden' value='purchlog_filter_by' name='wpsc_admin_action' />
      <input type="submit" value="<?php _e('Filter', 'wpsc'); ?>" name="doaction2" id="doaction2" class="button-secondary action" />    
   </div>

      <table class="widefat" cellspacing="5000">
         <thead>
            <tr>
         <?php print_column_headers('display-sales-list'); ?>
            </tr>
         </thead>
         <tfoot>
            <tr>
         <?php print_column_headers('display-sales-list', false); ?>
            </tr>
         </tfoot>
         <tbody>
             <!-- I can add the code here to retrieve things -->
         <?php 
         get_purchaselogs_content(); 
         ?>
         </tbody>
      </table>  
       </br>
       </br>

   </form>

<?php
 unset($_SESSION['newlogs']);
 }
//this is the content of the purchase log .... 
 function get_purchaselogs_content(){
     // I will do all the processing : checking the two selects : month status and search box 
           if( isset( $_POST['purchlogs_searchbox'] ) ){
               //using wpdb and seeing if there's a result then showing it
               $sterm = $_POST['purchlogs_searchbox'];
               global $wpdb;
               $searchres = $wpdb->get_results(
                    "select wp_posts.ID ,wp_posts.post_title,wp_product_stat.clicks FROM wp_posts inner join wp_product_stat on wp_posts.ID = wp_product_stat.prod_id  where wp_posts.post_type = 'wpsc-product' and wp_posts.post_title='".$sterm."'"
                );
               
                if(empty ($searchres) == 1){
                echo  '<div class="updated settings-error"><p>No Results</p></div> ';
                }
                else{
                    foreach ($searchres as $s){ ?>
        <tr>
                  <td><?php echo $s->ID ?></td><!-- purchase ID -->
                  <td><?php echo $s->post_title ?></td> <!--Date -->
                  <td><?php echo $s->quantity_sold   ?></td> <!--Name/email -->
                  <td><?php echo $s->clicks ?></td><!-- Amount -->
                  
                  </tr>
                 <?php   }
                }
               
     
               
 ?>
        
             <?php 
             }//end search for products 
             
             //begin filtering by most , least sold and most clicked
             if(isset($_POST['view_purchlogs_by']) || isset($_POST['view_purchlogs_by_status'])){
                 $status =  $_POST['view_purchlogs_by'];
                 $time = $_POST['view_purchlogs_by_status'];
                 
                 if($status == "msold" ){
                     if($time == "cmonth"){
                         global $wpdb;
                         $searchres = $wpdb->get_results("
SELECT wp_posts.post_title, wp_posts.ID AS ID, SUM( wp_order_product.quantity ) AS value, wp_product_stat.clicks
FROM wp_posts
INNER JOIN wp_order_product ON ID = wp_order_product.product_id
INNER JOIN wp_product_stat ON wp_order_product.product_id = wp_product_stat.prod_id
INNER JOIN wp_order ON wp_order_product.order_id = wp_order.id
WHERE MONTH( DATE ) = MONTH( CURDATE( ) ) 
GROUP BY ID
ORDER BY value DESC  ");
                     echo "<p><strong>Most Sold product this month</strong></p>"   ; 
                       $s = $searchres[0];
                     ?>
                  <tr>
                  <td><?php echo $s->ID ?></td><!-- purchase ID -->
                  <td><?php echo $s->post_title ?></td> <!--Date -->
                  <td><?php echo $s->value ?></td> <!--Name/email -->
                  <td><?php echo $s->clicks ?></td><!-- Amount -->
                  </tr>
                 <?php       
                 }//end current month
                 
                 
                     if($time == "all"){
                                                global $wpdb;
                         $searchres = $wpdb->get_results("
SELECT wp_posts.post_title, wp_posts.ID AS ID, SUM( wp_order_product.quantity ) AS value, wp_product_stat.clicks
FROM wp_posts
INNER JOIN wp_order_product ON ID = wp_order_product.product_id
INNER JOIN wp_product_stat ON wp_order_product.product_id = wp_product_stat.prod_id
INNER JOIN wp_order ON wp_order_product.order_id = wp_order.id
GROUP BY ID
ORDER BY value DESC  ");
                     echo "<p><strong>Most Sold product of all time</strong></p>";  
                       $s = $searchres[0];
                     ?>
                  <tr>
                  <td><?php echo $s->ID ?></td><!-- purchase ID -->
                  <td><?php echo $s->post_title ?></td> <!--Date -->
                  <td><?php echo $s->value ?></td> <!--Name/email -->
                  <td><?php echo $s->clicks ?></td><!-- Amount -->
                  </tr>
                 <?php  
                     
                     } //end all time 
                     
                     
                     
                 }//end most sold 
                 
                 
                 
                 if($status == "lsold" ){
                                          if($time == "cmonth"){
                         global $wpdb;
                         $searchres = $wpdb->get_results("
SELECT wp_posts.post_title, wp_posts.ID AS ID, SUM( wp_order_product.quantity ) AS value, wp_product_stat.clicks
FROM wp_posts
INNER JOIN wp_order_product ON ID = wp_order_product.product_id
INNER JOIN wp_product_stat ON wp_order_product.product_id = wp_product_stat.prod_id
INNER JOIN wp_order ON wp_order_product.order_id = wp_order.id
WHERE MONTH( DATE ) = MONTH( CURDATE( ) ) 
GROUP BY ID
ORDER BY value ASC  ");
                     echo "<p><strong>Least Sold product of all time</strong></p>";  
                       $s = $searchres[0];
                     ?>
                  <tr>
                  <td><?php echo $s->ID ?></td><!-- purchase ID -->
                  <td><?php echo $s->post_title ?></td> <!--Date -->
                  <td><?php echo $s->value ?></td> <!--Name/email -->
                  <td><?php echo $s->clicks ?></td><!-- Amount -->
                  </tr>
                 <?php    
                 }//end current month
                 
                 
                     if($time == "all"){
                                                global $wpdb;
                         $searchres = $wpdb->get_results("
SELECT wp_posts.post_title, wp_posts.ID AS ID, SUM( wp_order_product.quantity ) AS value, wp_product_stat.clicks
FROM wp_posts
INNER JOIN wp_order_product ON ID = wp_order_product.product_id
INNER JOIN wp_product_stat ON wp_order_product.product_id = wp_product_stat.prod_id
INNER JOIN wp_order ON wp_order_product.order_id = wp_order.id
GROUP BY ID
ORDER BY value ASC  ");
                     echo "<p><strong>Least Sold product of all time</strong></p>";  
                       $s = $searchres[0];
                     ?>
                  <tr>
                  <td><?php echo $s->ID ?></td><!-- purchase ID -->
                  <td><?php echo $s->post_title ?></td> <!--Date -->
                  <td><?php echo $s->value ?></td> <!--Name/email -->
                  <td><?php echo $s->clicks ?></td><!-- Amount -->
                  </tr>
                 <?php  
                     
                     } //end all time 
                 }//end least sold
                 
                 
                 
                 
                 
                 if($status == "clicks" ){
                                          if($time == "cmonth"){
                         global $wpdb;
                         $searchres = $wpdb->get_results("
SELECT wp_posts.post_title, wp_posts.ID AS ID, SUM( wp_order_product.quantity ) AS value, wp_product_stat.clicks as cl
FROM wp_posts
INNER JOIN wp_order_product ON ID = wp_order_product.product_id
INNER JOIN wp_product_stat ON wp_order_product.product_id = wp_product_stat.prod_id
INNER JOIN wp_order ON wp_order_product.order_id = wp_order.id
GROUP BY ID
ORDER BY cl DESC  ");
                     echo "<p><strong>Most clicked product</strong></p>"   ; 
                        
                       foreach($searchres as $s) {
                     ?>
                  <tr>
                  <td><?php echo $s->ID ?></td><!-- purchase ID -->
                  <td><?php echo $s->post_title ?></td> <!--Date -->
                  <td><?php echo $s->value ?></td> <!--Name/email -->
                  <td><?php echo $s->cl ?></td><!-- Amount -->
                  </tr>
                 <?php  }     
                 }//end current month
                 
                 
                     if($time == "all"){
                                                global $wpdb;
                         $searchres = $wpdb->get_results("
SELECT wp_posts.post_title, wp_posts.ID AS ID, SUM( wp_order_product.quantity ) AS value, wp_product_stat.clicks as cl
FROM wp_posts
INNER JOIN wp_order_product ON ID = wp_order_product.product_id
INNER JOIN wp_product_stat ON wp_order_product.product_id = wp_product_stat.prod_id
INNER JOIN wp_order ON wp_order_product.order_id = wp_order.id
GROUP BY ID
ORDER BY cl DESC  ");
                     echo "<p><strong>Most clicked product</strong></p>";  
                       foreach ($searchres as $s){
                     ?>
                  <tr>
                  <td><?php echo $s->ID ?></td><!-- purchase ID -->
                  <td><?php echo $s->post_title ?></td> <!--Date -->
                  <td><?php echo $s->value ?></td> <!--Name/email -->
                  <td><?php echo $s->cl ?></td><!-- Amount -->
                  </tr>
                 <?php  }
                     
                     } //end all time 
                     
                     
                     
                 }//end clicks
                 
                 
                 
                 
             }
             
             
             
             
             
             ?>
     
     
    

   <?php
  
 }//end get purchase content 
 
 
 
 
 //this is the content of the purchase log .... 
 function get_order_content(){
     // I will do all the processing : checking the two selects : month status and search box 
           if( isset( $_POST['purchlogs_searchbox'] ) ){
               //using wpdb and seeing if there's a result then showing it
               $sterm = $_POST['purchlogs_searchbox'];
               echo $sterm;
               global $wpdb;
               $searchres = $wpdb->get_results(
                    "select wp_posts.ID ,wp_posts.post_title,wp_product_stat.clicks FROM wp_posts inner join wp_product_stat on wp_posts.ID = wp_product_stat.prod_id  where wp_posts.post_type = 'wpsc-product' and wp_posts.post_title='".$sterm."'"
                );
               
                if(empty ($searchres) == 1){
                echo  '<div class="updated settings-error"><p>No Results</p></div> ';
                }
                else{
                    foreach ($searchres as $s){ ?>
        <tr>
                  <td><?php echo $s->ID ?></td><!-- purchase ID -->
                  <td><?php echo $s->post_title ?></td> <!--Date -->
                  <td><?php echo $s->quantity_sold   ?></td> <!--Name/email -->
                  <td><?php echo $s->clicks ?></td><!-- Amount -->
                  
                  </tr>
                 <?php   }
                }
               
     
               
 ?>
        
             <?php 
             }//end search for products 
             
             //begin filtering by most , least sold and most clicked
             if(isset($_POST['view_purchlogs_by']) || isset($_POST['view_purchlogs_by_status'])){
                 $status =  $_POST['view_purchlogs_by'];
                 $time = $_POST['view_purchlogs_by_status'];
                 
                 if($status == "msold" ){
                     if($time == "cmonth"){
                         global $wpdb;
                         $searchres = $wpdb->get_results("
SELECT wp_posts.post_title, wp_posts.ID AS ID, SUM( wp_order_product.quantity ) AS value, wp_product_stat.clicks
FROM wp_posts
INNER JOIN wp_order_product ON ID = wp_order_product.product_id
INNER JOIN wp_product_stat ON wp_order_product.product_id = wp_product_stat.prod_id
INNER JOIN wp_order ON wp_order_product.order_id = wp_order.id
WHERE MONTH( DATE ) = MONTH( CURDATE( ) ) 
GROUP BY ID
ORDER BY value DESC  ");
                     echo "<p><strong>Most Sold product this month</strong></p>"   ; 
                       $s = $searchres[0];
                     ?>
                  <tr>
                  <td><?php echo $s->ID ?></td><!-- purchase ID -->
                  <td><?php echo $s->post_title ?></td> <!--Date -->
                  <td><?php echo $s->value ?></td> <!--Name/email -->
                  <td><?php echo $s->clicks ?></td><!-- Amount -->
                  </tr>
                 <?php       
                 }//end current month
                 
                 
                     if($time == "all"){
                                                global $wpdb;
                         $searchres = $wpdb->get_results("
SELECT wp_posts.post_title, wp_posts.ID AS ID, SUM( wp_order_product.quantity ) AS value, wp_product_stat.clicks
FROM wp_posts
INNER JOIN wp_order_product ON ID = wp_order_product.product_id
INNER JOIN wp_product_stat ON wp_order_product.product_id = wp_product_stat.prod_id
INNER JOIN wp_order ON wp_order_product.order_id = wp_order.id
GROUP BY ID
ORDER BY value DESC  ");
                     echo "<p><strong>Most Sold product of all time</strong></p>";  
                       $s = $searchres[0];
                     ?>
                  <tr>
                  <td><?php echo $s->ID ?></td><!-- purchase ID -->
                  <td><?php echo $s->post_title ?></td> <!--Date -->
                  <td><?php echo $s->value ?></td> <!--Name/email -->
                  <td><?php echo $s->clicks ?></td><!-- Amount -->
                  </tr>
                 <?php  
                     
                     } //end all time 
                     
                     
                     
                 }//end most sold 
                 
                 
                 
                 if($status == "lsold" ){
                                          if($time == "cmonth"){
                         global $wpdb;
                         $searchres = $wpdb->get_results("
SELECT wp_posts.post_title, wp_posts.ID AS ID, SUM( wp_order_product.quantity ) AS value, wp_product_stat.clicks
FROM wp_posts
INNER JOIN wp_order_product ON ID = wp_order_product.product_id
INNER JOIN wp_product_stat ON wp_order_product.product_id = wp_product_stat.prod_id
INNER JOIN wp_order ON wp_order_product.order_id = wp_order.id
WHERE MONTH( DATE ) = MONTH( CURDATE( ) ) 
GROUP BY ID
ORDER BY value ASC  ");
                     echo "<p><strong>Least Sold product of all time</strong></p>";  
                       $s = $searchres[0];
                     ?>
                  <tr>
                  <td><?php echo $s->ID ?></td><!-- purchase ID -->
                  <td><?php echo $s->post_title ?></td> <!--Date -->
                  <td><?php echo $s->value ?></td> <!--Name/email -->
                  <td><?php echo $s->clicks ?></td><!-- Amount -->
                  </tr>
                 <?php    
                 }//end current month
                 
                 
                     if($time == "all"){
                                                global $wpdb;
                         $searchres = $wpdb->get_results("
SELECT wp_posts.post_title, wp_posts.ID AS ID, SUM( wp_order_product.quantity ) AS value, wp_product_stat.clicks
FROM wp_posts
INNER JOIN wp_order_product ON ID = wp_order_product.product_id
INNER JOIN wp_product_stat ON wp_order_product.product_id = wp_product_stat.prod_id
INNER JOIN wp_order ON wp_order_product.order_id = wp_order.id
GROUP BY ID
ORDER BY value ASC  ");
                     echo "<p><strong>Least Sold product of all time</strong></p>";  
                       $s = $searchres[0];
                     ?>
                  <tr>
                  <td><?php echo $s->ID ?></td><!-- purchase ID -->
                  <td><?php echo $s->post_title ?></td> <!--Date -->
                  <td><?php echo $s->value ?></td> <!--Name/email -->
                  <td><?php echo $s->clicks ?></td><!-- Amount -->
                  </tr>
                 <?php  
                     
                     } //end all time 
                 }//end least sold
                 
                 
                 
                 
                 
                 if($status == "clicks" ){
                                          if($time == "cmonth"){
                         global $wpdb;
                         $searchres = $wpdb->get_results("
SELECT wp_posts.post_title, wp_posts.ID AS ID, SUM( wp_order_product.quantity ) AS value, wp_product_stat.clicks as cl
FROM wp_posts
INNER JOIN wp_order_product ON ID = wp_order_product.product_id
INNER JOIN wp_product_stat ON wp_order_product.product_id = wp_product_stat.prod_id
INNER JOIN wp_order ON wp_order_product.order_id = wp_order.id
GROUP BY ID
ORDER BY cl DESC  ");
                     echo "<p><strong>Most clicked product</strong></p>"   ; 
                        
                       foreach($searchres as $s) {
                     ?>
                  <tr>
                  <td><?php echo $s->ID ?></td><!-- purchase ID -->
                  <td><?php echo $s->post_title ?></td> <!--Date -->
                  <td><?php echo $s->value ?></td> <!--Name/email -->
                  <td><?php echo $s->cl ?></td><!-- Amount -->
                  </tr>
                 <?php  }     
                 }//end current month
                 
                 
                     if($time == "all"){
                                                global $wpdb;
                         $searchres = $wpdb->get_results("
SELECT wp_posts.post_title, wp_posts.ID AS ID, SUM( wp_order_product.quantity ) AS value, wp_product_stat.clicks as cl
FROM wp_posts
INNER JOIN wp_order_product ON ID = wp_order_product.product_id
INNER JOIN wp_product_stat ON wp_order_product.product_id = wp_product_stat.prod_id
INNER JOIN wp_order ON wp_order_product.order_id = wp_order.id
GROUP BY ID
ORDER BY cl DESC  ");
                     echo "<p><strong>Most clicked product</strong></p>";  
                       foreach ($searchres as $s){
                     ?>
                  <tr>
                  <td><?php echo $s->ID ?></td><!-- purchase ID -->
                  <td><?php echo $s->post_title ?></td> <!--Date -->
                  <td><?php echo $s->value ?></td> <!--Name/email -->
                  <td><?php echo $s->cl ?></td><!-- Amount -->
                  </tr>
                 <?php  }
                     
                     } //end all time 
                     
                     
                     
                 }//end clicks
                 
                 
                 
                 
             }
             
             
             
             
             
             ?>
     
     
    

   <?php
  
 }//end get purchase content
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 function wpsc_purchaselogs_searchbox(){
   ?>
   <form  action='' method='post'>
      
   </form>
   <?php
 }

 
 //this is the detail box below 
 function wpsc_display_purchlog_details(){
   while( wpsc_have_purchaselog_details() ) : wpsc_the_purchaselog_item(); ?>
   <tr>
      <td><?php echo wpsc_purchaselog_details_name(); ?></td> <!-- NAME! -->
      <td><?php echo wpsc_purchaselog_details_SKU(); ?></td> <!-- SKU! -->
      <td><?php echo wpsc_purchaselog_details_quantity(); ?></td> <!-- QUANTITY! -->
      <td><?php echo wpsc_currency_display( wpsc_purchaselog_details_price() ); ?></td> <!-- PRICE! -->
      <td><?php echo wpsc_currency_display( wpsc_purchaselog_details_shipping() ); ?></td> <!-- SHIPPING! -->
      <td><?php if(wpec_display_product_tax()) { echo wpsc_currency_display(wpsc_purchaselog_details_tax()); } ?></td> <!-- TAX! -->
      <!-- <td><?php echo wpsc_currency_display( wpsc_purchaselog_details_discount() ); ?></td> --> <!-- DISCOUNT! -->
      <td><?php echo wpsc_currency_display( wpsc_purchaselog_details_total() ); ?></td> <!-- TOTAL! -->
   </tr>
<?php
   endwhile;
}

function wpsc_purchlogs_custom_fields(){
   if(wpsc_purchlogs_has_customfields()){?>
   <div class='metabox-holder'>
      <div id='purchlogs_customfields' class='postbox'>
      <h3 class='hndle'><?php _e( 'Users Custom Fields' , 'wpsc' ); ?></h3>
      <div class='inside'>
      <?php $messages = wpsc_purchlogs_custommessages(); ?>
      <?php $files = wpsc_purchlogs_customfiles(); ?>
      <?php if(count($files) > 0){ ?>
      <h4><?php _e( 'Cart Items with Custom Files' , 'wpsc' ); ?>:</h4>
      <?php
         foreach($files as $file){
            echo "<p>".esc_html($file)."</p>";
         }
      }?>
      <?php if(count($messages) > 0){ ?>
      <h4><?php _e( 'Cart Items with Custom Messages' , 'wpsc' ); ?>:</h4>
      <?php
         foreach($messages as $message){
            echo "<p>".esc_html($message)."</p>";
         }
      } ?>
      </div>
      </div>
      </div>
<?php }

}



?>
