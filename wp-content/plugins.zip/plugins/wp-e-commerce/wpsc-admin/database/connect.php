<?php
include_once("database.php");  
		global $db;	  	
		$db = new databaseConnection("localhost","javasop_zahrah","javasop_zahrah","zahrahcp1989");
		$db->connect();
   
?>