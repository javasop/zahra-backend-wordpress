<?php
global $cab_default_css;
$cab_default_css = "#wpadminbar * {}
#wpadminbar ul li:before,#wpadminbar ul li:after {}
#wpadminbar a,#wpadminbar a:hover,#wpadminbar a img,#wpadminbar a img:hover {}
#wpadminbar {}
#wpadminbar .ab-sub-wrapper,#wpadminbar ul,#wpadminbar ul li {}
#wpadminbar .quicklinks {}
#wpadminbar .quicklinks ul {}
#wpadminbar li {}
#wpadminbar .ab-empty-item {}
#wpadminbar .quicklinks>ul>li {}
#wpadminbar .quicklinks>ul>li>a,#wpadminbar .quicklinks>ul>li>.ab-empty-item {}
#wpadminbar .quicklinks .ab-top-secondary>li {}
#wpadminbar .quicklinks .ab-top-secondary>li>a,#wpadminbar .quicklinks .ab-top-secondary>li>.ab-empty-item {}
#wpadminbar .quicklinks a,#wpadminbar .quicklinks .ab-empty-item,#wpadminbar .shortlink-input {}
#wpadminbar .menupop .ab-sub-wrapper,#wpadminbar .shortlink-input {}
#wpadminbar.ie7 .menupop .ab-sub-wrapper,#wpadminbar.ie7 .shortlink-input {}
#wpadminbar .ab-top-secondary .menupop .ab-sub-wrapper {}
#wpadminbar .ab-sub-wrapper>.ab-submenu:first-child {}
#wpadminbar .ab-submenu {}
#wpadminbar .selected .shortlink-input {}
#wpadminbar .quicklinks .menupop ul li {}
#wpadminbar .quicklinks .menupop ul li a strong {}
#wpadminbar .quicklinks .menupop ul li .ab-item,#wpadminbar .quicklinks .menupop ul li a strong,#wpadminbar .quicklinks .menupop.hover ul li .ab-item,#wpadminbar.nojs .quicklinks .menupop:hover ul li .ab-item,#wpadminbar .shortlink-input {}
#wpadminbar .shortlink-input {}
#wpadminbar.nojs li:hover>.ab-sub-wrapper,#wpadminbar li.hover>.ab-sub-wrapper {}
#wpadminbar .menupop li:hover>.ab-sub-wrapper,#wpadminbar .menupop li.hover>.ab-sub-wrapper {}
#wpadminbar .ab-top-secondary .menupop li:hover>.ab-sub-wrapper,#wpadminbar .ab-top-secondary .menupop li.hover>.ab-sub-wrapper {}
#wpadminbar .ab-top-menu>li:hover>.ab-item,#wpadminbar .ab-top-menu>li.hover>.ab-item,#wpadminbar .ab-top-menu>li>.ab-item:focus,#wpadminbar.nojq .quicklinks .ab-top-menu>li>.ab-item:focus {}
#wpadminbar.nojs .ab-top-menu>li.menupop:hover>.ab-item,#wpadminbar .ab-top-menu>li.menupop.hover>.ab-item {}
#wpadminbar .hover .ab-label,#wpadminbar.nojq .ab-item:focus .ab-label {}
#wpadminbar .menupop.hover .ab-label {}
#wpadminbar .menupop li:hover,#wpadminbar .menupop li.hover,#wpadminbar .quicklinks .menupop .ab-item:focus,#wpadminbar .quicklinks .ab-top-menu .menupop .ab-item:focus {}
#wpadminbar .ab-submenu .ab-item {}
#wpadminbar .quicklinks .menupop ul li a,#wpadminbar .quicklinks .menupop ul li a strong,#wpadminbar .quicklinks .menupop.hover ul li a,#wpadminbar.nojs .quicklinks .menupop:hover ul li a {}
#wpadminbar .menupop .menupop>.ab-item {}
#wpadminbar .ab-top-secondary .menupop .menupop>.ab-item {}
#wpadminbar .quicklinks .menupop ul.ab-sub-secondary {}
#wpadminbar .quicklinks .menupop .ab-sub-secondary>li:hover,#wpadminbar .quicklinks .menupop .ab-sub-secondary>li.hover,#wpadminbar .quicklinks .menupop .ab-sub-secondary>li .ab-item:focus {}
#wpadminbar .quicklinks a span#ab-updates {}
#wpadminbar .quicklinks a:hover span#ab-updates {}
#wpadminbar .ab-top-secondary {}
#wpadminbar ul li:last-child,#wpadminbar ul li:last-child .ab-item {}
#wp-admin-bar-my-account>ul {}
#wp-admin-bar-my-account.with-avatar>ul {}
#wpadminbar #wp-admin-bar-user-actions>li {}
#wpadminbar #wp-admin-bar-my-account.with-avatar #wp-admin-bar-user-actions>li {}
#wp-admin-bar-user-actions>li>.ab-item {}
#wpadminbar #wp-admin-bar-user-info {}
#wp-admin-bar-user-info .avatar {}
#wpadminbar #wp-admin-bar-user-info a {}
#wpadminbar #wp-admin-bar-user-info span {}
#wpadminbar #wp-admin-bar-user-info .display-name,#wpadminbar #wp-admin-bar-user-info .username {}
#wpadminbar #wp-admin-bar-user-info .display-name {}
#wpadminbar #wp-admin-bar-user-info .username {}
#wpadminbar .quicklinks li#wp-admin-bar-my-account.with-avatar>a img {}
#wpadminbar .quicklinks li img.blavatar {}
#wpadminbar #wp-admin-bar-search .ab-item {}
#wpadminbar #wp-admin-bar-search .ab-item {}
#wpadminbar #adminbarsearch {}
#wpadminbar #adminbarsearch .adminbar-input {}
#wpadminbar.ie7 #adminbarsearch .adminbar-input {}
#wpadminbar #adminbarsearch .adminbar-input:focus {}
#wpadminbar.ie8 #adminbarsearch .adminbar-input {}
#wpadminbar.ie8 #adminbarsearch .adminbar-input:focus {}
#wpadminbar #adminbarsearch .adminbar-input::-webkit-input-placeholder {}
#wpadminbar #adminbarsearch .adminbar-input:-moz-placeholder {}
#wpadminbar #adminbarsearch .adminbar-button {}
#wpadminbar #wp-admin-bar-appearance {}
#wpadminbar #wp-admin-bar-appearance {}
#wpadminbar .ab-icon {}
#wpadminbar .ab-label {}
#wp-admin-bar-wp-logo>.ab-item .ab-icon {}
#wpadminbar.nojs #wp-admin-bar-wp-logo:hover>.ab-item .ab-icon,#wpadminbar #wp-admin-bar-wp-logo.hover>.ab-item .ab-icon {}
#wp-admin-bar-updates>.ab-item .ab-icon {}
#wp-admin-bar-comments>.ab-item .ab-icon {}
#wpadminbar span.count-0 }
#wpadminbar #wp-admin-bar-new-content>.ab-item .ab-icon {}
#wpadminbar.nojs #wp-admin-bar-new-content:hover>.ab-item .ab-icon,#wpadminbar #wp-admin-bar-new-content.hover>.ab-item .ab-icon {}
* html #wpadminbar {}
* html #wpadminbar .quicklinks ul li a {}
* html #wpadminbar .menupop a span {}";

add_action('admin_init', 'regester_custom_adminbar_settings');
function regester_custom_adminbar_settings(){
	
	add_settings_section('main_section', 'Main Settings', 'main_section_disp_fnc', __FILE__);

	register_setting( 'custom-adminbar', 'custom-adminbar-enabled' );
	add_settings_field('custom-adminbar-enabled', 'Enable Admin Bar:', 'checkbox_fnc', __FILE__, 'main_section', array( 'name' => 'custom-adminbar-enabled', 'default' => true ) );
	
	register_setting( 'custom-adminbar', 'custom-adminbar-bump' );
	add_settings_field('custom-adminbar-bump', 'Enable Content Bump:', 'checkbox_fnc', __FILE__, 'main_section', array( 'name' => 'custom-adminbar-bump', 'default' => true ) );
	
	cab_register_role_options();
	
	add_settings_section('style_section', 'Custom CSS Styles', 'styles_disp_fnc', __FILE__);
	
	register_setting( 'custom-adminbar', 'custom-adminbar-styles', 'cab_styles_callback');
	global $cab_default_css;
	add_settings_field('custom-adminbar-styles', 'CSS Code:', 'textarea_fnc', __FILE__, 'style_section', array( 'name' => 'custom-adminbar-styles', 'default' => $cab_default_css ) );
}
function main_section_disp_fnc(){
	echo '<p>The menu items added to the front end are temporary controls for hiding the admin bar.<br />To reset these settings if you clicked either "Hide Site Wide" or "Hide For This Page", you can clear your cookies or simply close and re-open your browser.';

	echo "<p>Note: The 'Content Bump' is the 28px margin added to the top of the page.<br />
	This margin can causes problems with some layouts (<a href='http://wesleytodd.com/2011/02/wp31-admin-bar-removal-styling' target='_blank'>Read This Article</a>).</p>";
}
function user_settings_disp_fnc(){
	echo "<p>Select who can see the admin bar by user level.</p>";
}
function styles_disp_fnc(){
	echo "<p>Define Custom CSS for your admin bar.</p>";
}
function checkbox_fnc($args){
	$val = get_option($args['name'], $args['default']);
	$checked = '';
	if( $val ) { $checked = ' checked="checked" '; }
	echo "<input ".$checked." name='".$args['name']."' type='checkbox' />";
}
function textarea_fnc($args){
	$val = get_option($args['name'], $args['default']);
	
	echo "<textarea name='".$args['name']."' cols='67' rows='15'>$val</textarea>";
	if($args['name'] == 'custom-adminbar-styles'){ ?>
		<br /><input name="ResetStyle" type="submit" class="button-secondary" value="<?php esc_attr_e('Reset Styles'); ?>" />
	<?php }
}
function cab_styles_callback($var){
	if(isset($_POST['ResetStyle'])){
		global $cab_default_css;
		return $cab_default_css;
	}
	return $var;
}

/*
 * Register a setting for each avaliable role
 */
function cab_register_role_options(){
	add_settings_section('user_section', 'User Settings', 'user_settings_disp_fnc', __FILE__);
	$roles = cab_get_roles();
	foreach($roles as $role=>$name){
		$field_name = 'custom-adminbar-'.$role;
		$field_label = $name.':';
		register_setting( 'custom-adminbar', $field_name );
		add_settings_field($field_name, $field_label, 'checkbox_fnc', __FILE__, 'user_section', array( 'name' => $field_name, 'default' => true ) );
	}
}
add_action('admin_menu', 'custom_adminbar_menu');
function custom_adminbar_menu() {
	add_options_page('Admin Bar Options', 'Custom Admin Bar', 'manage_options', 'custom-adminbar-options-menu', 'custom_adminbar_options');
}
function custom_adminbar_options() {
	if (!current_user_can('manage_options')){
		wp_die( __('You do not have sufficient permissions to access this page.') );
	}
?>
<div class="wrap">
	<h2>Custom Admin Bar Options</h2>
	<div style="width:200px;float:right;padding:20px;border-:1px solid #DFDFDF;background-color:#F5F5F5;">
		<h3>Donations</h3>
		<p>If you feel grateful for the time I have donated to develop this plugin.  Please help me buy a beer by donating.</p>
		<form action="https://www.paypal.com/cgi-bin/webscr" method="post" style="margin-bottom:5px;">
			<label for="ammount1">Donate 50&cent;</label>
			<input type="hidden" name="cmd" value="_donations">
			<input type="hidden" name="business" value="wes@wesleytodd.com">
			<input type="hidden" name="lc" value="US">
			<input type="hidden" name="item_name" value="Wes Todd">
			<input type="hidden" name="amount" id="amount1" value="0.50">
			<input type="hidden" name="currency_code" value="USD">
			<input type="hidden" name="currency_code" value="USD">
			<input type="hidden" name="bn" value="PP-DonationsBF:btn_donate_SM.gif:NonHosted">
			<input type="image" style="vertical-align:middle;" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
			<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
		</form>
		<form action="https://www.paypal.com/cgi-bin/webscr" method="post" style="margin-bottom:5px;">
			<label for="amount2">Donate $1.00</label>
			<input type="hidden" name="cmd" value="_donations">
			<input type="hidden" name="business" value="wes@wesleytodd.com">
			<input type="hidden" name="lc" value="US">
			<input type="hidden" name="item_name" value="Wes Todd">
			<input type="hidden" name="amount" id="amount2" value="1.00">
			<input type="hidden" name="currency_code" value="USD">
			<input type="hidden" name="currency_code" value="USD">
			<input type="hidden" name="bn" value="PP-DonationsBF:btn_donate_SM.gif:NonHosted">
			<input type="image" style="vertical-align:middle;" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
			<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
		</form>
		<form action="https://www.paypal.com/cgi-bin/webscr" method="post" style="margin-bottom:5px;">
			<input type="hidden" name="cmd" value="_donations">
			<input type="hidden" name="business" value="wes@wesleytodd.com">
			<input type="hidden" name="lc" value="US">
			<input type="hidden" name="item_name" value="Wes Todd">
			$<input type="text" name="amount" id="amount3" value="5.00" style="width:75px;">
			<input type="hidden" name="currency_code" value="USD">
			<input type="hidden" name="currency_code" value="USD">
			<input type="hidden" name="bn" value="PP-DonationsBF:btn_donate_SM.gif:NonHosted">
			<input type="image" style="vertical-align:middle;" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
			<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
		</form>
	</div>
	<form action="options.php" method="post" style="float:left;">
		<?php settings_fields('custom-adminbar');
		do_settings_sections(__FILE__); ?>
		<p class="submit">
			<input name="Submit" type="submit" class="button-primary" value="<?php esc_attr_e('Save Changes'); ?>" />
		</p>
	</form>
</div>
<?php
}
//END options page stuff